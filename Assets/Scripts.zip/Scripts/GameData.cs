public static class GameData
{
    public static int CurrentLevel { get; set; } // Индекс текущего уровня
    public static int LevelScoreGoal { get; set; } // Цель по очкам для уровня
    public static float LevelTimeLimit { get; set; } // Лимит времени для уровня
}