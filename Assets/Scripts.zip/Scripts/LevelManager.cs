using UnityEngine;

public class LevelManager : MonoBehaviour
{
    public static LevelManager Instance;

    public LevelDataSO[] levels; // Массив данных уровней

    private const string ProgressKey = "LevelProgress";
    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);

            // Проверяем, есть ли сохраненные данные
            if (!PlayerPrefs.HasKey(ProgressKey))
            {
                UnlockUpToLevel(0); // Разблокируем только уровень 0 при первом запуске
            }
            else
            {
                LoadLevelProgress(); // Загружаем сохраненные данные
            }
        }
        else
        {
            Destroy(gameObject);
        }
    }


    public void UnlockUpToLevel(int levelIndex)
    {
        Debug.Log($"Unlocking levels up to index {levelIndex}");
        for (int i = 0; i <= levelIndex; i++)
        {
            if (i < levels.Length)
            {
                levels[i].isUnlocked = true;
            }
        }
        SaveLevelProgress();
    }


    public void LoadLevelData(int levelIndex)
    {
        if (levelIndex < levels.Length)
        {
            GameData.CurrentLevel = levels[levelIndex].levelIndex;
            GameData.LevelScoreGoal = levels[levelIndex].scoreGoal;
            GameData.LevelTimeLimit = levels[levelIndex].timeLimit;
        }
    }

    public void AddLevel(int levelIndex, int scoreGoal, float timeLimit, bool isUnlocked)
    {
        if (levelIndex < levels.Length)
        {
            LevelDataSO newLevel = ScriptableObject.CreateInstance<LevelDataSO>();
            newLevel.levelIndex = levelIndex;
            newLevel.scoreGoal = scoreGoal;
            newLevel.timeLimit = timeLimit;
            newLevel.isUnlocked = isUnlocked;
            levels[levelIndex] = newLevel;
        }
    }

    public bool IsLevelUnlocked(int levelIndex)
    {
        if (levelIndex < levels.Length)
        {
            return levels[levelIndex ].isUnlocked;
        }
        return false;
    }

   public void UnlockNextLevel(int levelIndex)
{
    int nextLevel = levelIndex + 1;
    if (nextLevel < levels.Length)
    {
        levels[nextLevel].isUnlocked = true;
        SaveLevelProgress();
    }
}


    public void SaveLevelProgress()
    {
        string progress = "";
        foreach (var level in levels)
        {
            progress += level.levelIndex + "," + (level.isUnlocked ? "1" : "0") + ";";
        }
        PlayerPrefs.SetString(ProgressKey, progress);
        PlayerPrefs.Save();
    }

    private void LoadLevelProgress()
    {
        string progress = PlayerPrefs.GetString(ProgressKey, "0,1;"); // Уровень 0 разблокирован
        string[] levelDataArray = progress.Split(';');

        foreach (string levelData in levelDataArray)
        {
            if (string.IsNullOrEmpty(levelData)) continue;

            string[] data = levelData.Split(',');
            int levelIndex = int.Parse(data[0]);
            bool isUnlocked = data[1] == "1";

            if (levelIndex < levels.Length)
            {
                levels[levelIndex].isUnlocked = isUnlocked;
            }
        }

        LogLevelStatus(); // Выводим в лог текущий статус уровней
    }


    public void LogLevelStatus()
    {
        Debug.Log("Level Status:");
        for (int i = 0; i < levels.Length; i++)
        {
            string status = levels[i].isUnlocked ? "Unlocked" : "Locked";
            Debug.Log($"Level {levels[i].levelIndex}: {status}");
        }
    }

}
