using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    public int currentScore = 0;
    public float timeRemaining;
    private bool levelCompleted = false;

    public int currentHealth = 100; // Здоровье игрока
    public int maxHealth = 100;

    public UIManager manager;
    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }

        manager = GameObject.Find("Canvas").GetComponent<UIManager>();
    }

    void Start()
    {
        InitializeLevel();
    }

    void Update()
    {
        if (!levelCompleted)
        {
            // Уменьшаем оставшееся время
            timeRemaining -= Time.deltaTime;

            // Обновляем слайдер времени
            manager.UpdateTime(timeRemaining, GameData.LevelTimeLimit);

            // Проверяем, если время истекло
            if (timeRemaining <= 0)
            {
                GameOver();
            }
        }
    }

    public void InitializeLevel()
    {
        // Устанавливаем начальные значения
        LevelManager.Instance.LoadLevelData(GameData.CurrentLevel);
        currentScore = 0;
        timeRemaining = GameData.LevelTimeLimit;
        currentHealth = maxHealth;

        // Теперь обновляем UI
        manager.UpdateHealth(currentHealth, maxHealth);
        manager.UpdateTime(timeRemaining, GameData.LevelTimeLimit);
        manager.UpdateScore(currentScore, GameData.LevelScoreGoal);

        Debug.Log($"Level {GameData.CurrentLevel} initialized");
    }

    
    public void AddScore(int score)
    {
        currentScore += score;
        manager.UpdateScore(currentScore, GameData.LevelScoreGoal); // Обновляем UI

        if (currentScore >= GameData.LevelScoreGoal && !levelCompleted)
        {
            CompleteLevel();
        }
    }


    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        if (currentHealth <= 0)
        {
            GameOver();
        }
    }

    public void Heal(int healAmount)
    {
        currentHealth = Mathf.Min(currentHealth + healAmount, maxHealth);
    }

    void CompleteLevel()
    {
        levelCompleted = true;
        Debug.Log("Level Completed!");
        LevelManager.Instance.UnlockNextLevel(GameData.CurrentLevel);

        // Сохранить прогресс
        PlayerPrefs.SetInt("LastUnlockedLevel", GameData.CurrentLevel + 1);
        PlayerPrefs.Save();

        // Загрузить следующий уровень или экран завершения
        SceneManager.LoadScene("LevelCompleteMenu");
    }

    public void GameOver()
    {
        Debug.Log("Game Over!");
        // Загрузить экран поражения или перезапустить уровень
        SceneManager.LoadScene("GameOverMenu");
    }
}
