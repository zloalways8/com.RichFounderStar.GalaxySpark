using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuManager : MonoBehaviour
{
    public GameObject levelPanel; // Панель уровней
    public GameObject mainMenuPanel; // Главное меню

    void Start()
    {
        // Проверяем сохранённые данные
        if (LevelManager.Instance != null)
        {
            int lastUnlockedLevel = PlayerPrefs.GetInt("LastUnlockedLevel", 0); // Если нет сохранения, вернуть 0

            if (lastUnlockedLevel == 0) // Если ни один уровень не разблокирован
            {
                PlayerPrefs.SetInt("LastUnlockedLevel", 1); // Разблокировать первый уровень
                PlayerPrefs.Save();
                LevelManager.Instance.UnlockUpToLevel(1); // Разблокировать уровень 1 в памяти
            }
            else
            {
                LevelManager.Instance.UnlockUpToLevel(lastUnlockedLevel);
            }
        }
        else
        {
            Debug.LogError("LevelManager instance is missing!");
        }

        // Добавляем уровни, если это требуется
        LevelManager.Instance.AddLevel(1, 100, 60, true);  // Уровень 1
        LevelManager.Instance.AddLevel(2, 200, 70, false); // Уровень 2

        // Показываем главное меню по умолчанию
        ShowMainMenu();
    }

    public void StartGame()
    {
        // Если есть последний сохранённый уровень, загружаем его, иначе первый уровень
        int lastUnlockedLevel = PlayerPrefs.GetInt("LastUnlockedLevel", 1);

        if (LevelManager.Instance != null)
        {
            LevelManager.Instance.LoadLevelData(lastUnlockedLevel);
            GameData.CurrentLevel = lastUnlockedLevel;
        }
        else
        {
            Debug.LogError("LevelManager instance is missing!");
        }

        LoadLevel(lastUnlockedLevel);
    }

    public void OpenLevelsPanel()
    {
        // Переключение из главного меню в меню выбора уровней
        if (mainMenuPanel != null) mainMenuPanel.SetActive(false);
        if (levelPanel != null) levelPanel.SetActive(true);
    }

    public void BackToMainMenu()
    {
        // Переключение из меню выбора уровней в главное меню
        if (levelPanel != null) levelPanel.SetActive(false);
        if (mainMenuPanel != null) mainMenuPanel.SetActive(true);
    }

    public void LoadLevel(int levelIndex)
    {
        // Проверяем, разблокирован ли уровень
        if (LevelManager.Instance != null && LevelManager.Instance.IsLevelUnlocked(levelIndex))
        {
            GameData.CurrentLevel = levelIndex; // Установить текущий уровень
            LevelManager.Instance.LoadLevelData(levelIndex);
            SceneManager.LoadScene("GameScene"); // Сцена с игрой
        }
        else
        {
            Debug.Log($"Level {levelIndex} is locked!");
        }
    }

    private void ShowMainMenu()
    {
        // Убедитесь, что только главное меню активно
        if (mainMenuPanel != null) mainMenuPanel.SetActive(true);
        if (levelPanel != null) levelPanel.SetActive(false);
    }
}
