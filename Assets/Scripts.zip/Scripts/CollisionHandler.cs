using UnityEngine;

public class CollisionHandler : MonoBehaviour
{
    public HealthManager healthManager;
    public GameManager gameController;

    void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log($"Collision detected with: {collision.name}, Tag: {collision.tag}");

        if (collision.CompareTag("Gem"))
        {
            Debug.Log("Gem collected! Adding score.");
            gameController.AddScore(10);
            Destroy(collision.gameObject);
        }
        else if (collision.CompareTag("Comet"))
        {
            Debug.Log("Comet hit! Reducing health.");
            healthManager.TakeDamage(20);
            Destroy(collision.gameObject);
        }
        else if (collision.CompareTag("Heart"))
        {
            Debug.Log("Heart collected! Restoring health.");
            healthManager.Heal(10);
            Destroy(collision.gameObject);
        }
        else
        {
            Debug.LogWarning($"Unhandled collision with: {collision.name}, Tag: {collision.tag}");
        }
    }
}