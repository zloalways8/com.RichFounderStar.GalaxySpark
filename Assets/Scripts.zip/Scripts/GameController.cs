// GameController.cs
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public int targetScore = 500; // Необходимые очки
    private int currentScore = 0;
    private bool levelCompleted = false;

    public UIManager uiManager;
    public void AddScore(int score)
    {
        if (levelCompleted) return;

        currentScore += score;
        uiManager.UpdateScore(currentScore, targetScore);

        if (currentScore >= targetScore)
        {
            CompleteLevel();
        }
    }

    void CompleteLevel()
    {
        levelCompleted = true;
        Debug.Log("Level Completed!");
        // Переход на следующий уровень или экран победы
        LevelManager.Instance.UnlockNextLevel(GameData.CurrentLevel + 1);
        SceneManager.LoadScene("WinScene");
    }

    public void FailLevel()
    {
        levelCompleted = true;
        Debug.Log("Level Failed!");
        SceneManager.LoadScene("GameOverScene");
    }
}